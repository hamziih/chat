<?php
$lang['gifs'] = 'Gifs';
$lang['stickers'] = 'Stickers';
$lang['max_stickers'] = 'Stickers load count';
$lang['max_gifs'] = 'Gifs load count';
$lang['giphy_key'] = 'Giphy api key';
?>