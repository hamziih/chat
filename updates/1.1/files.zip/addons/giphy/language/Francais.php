<?php
$lang['gifs'] = 'Gifs';
$lang['stickers'] = 'Stickers';
$lang['max_stickers'] = 'Nombre résultats stickers';
$lang['max_gifs'] = 'Nombre résultats gifs';
$lang['giphy_key'] = 'Clé Giphy';
?>