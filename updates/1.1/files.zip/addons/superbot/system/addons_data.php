<?php
$ad = array(
	'name' => 'superbot',
	'js' => 2,
	'bot_name'=> 'Superbot',
	'bot_type'=> 1,
	);
?>