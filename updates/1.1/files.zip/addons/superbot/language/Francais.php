<?php
// menu superbot

$lang['question'] = 'Question';
$lang['answers'] = 'Réponses';
?>