<?php
// menu superbot

$lang['question'] = 'Вопрос';
$lang['answers'] = 'Ответы';

?>