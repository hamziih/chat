<div data="" value="" class="elem_in aclist aclist_name gprivate rself">
	<span class="list_icon"><i class="fa fa-comments theme_color"></i></span><?php echo $lang['private_chat']; ?>
</div>
<div data="" class="elem_in aclist get_info rglobal">
	<span class="list_icon"><i class="fa fa-user-circle-o default_color"></i></span><?php echo $lang['info']; ?>
</div>
<!--
<?php if(boomAllow(8)){ ?>
	<div data="" onclick="listAction(this, 'mute');" class="elem_in aclist list_action rhigh">
		<span class="list_icon"><i class="fa fa-microphone-slash warn"></i></span><?php echo $lang['mute']; ?>
	</div>
	<div data="" onclick="listAction(this, 'unmute');" class="elem_in aclist list_action rhigh">
		<span class="list_icon"><i class="fa fa-microphone success"></i></span><?php echo $lang['unmute']; ?>
	</div>
<?php } ?>
<?php if(boomAllow(10)){ ?>
	<div data="" onclick="listAction(this, 'ban');" class="elem_in aclist list_action rhigh">
		<span class="list_icon"><i class="fa fa-ban error"></i></span><?php echo $lang['ban']; ?>
	</div>
<?php } ?>
-->
